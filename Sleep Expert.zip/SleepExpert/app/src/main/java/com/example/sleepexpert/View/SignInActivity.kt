package com.example.sleepexpert.View

import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.*
import com.example.sleepexpert.R
import com.example.sleepexpert.UserApplication
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.ViewModel.RegisterViewModel
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.database.User
import com.example.sleepexpert.model.user
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class SignInActivity : AppCompatActivity() {

    private lateinit var loginViewModel: LoginViewModel

    private lateinit var e_mail: EditText
    private lateinit var password: EditText



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        val signUpButton = findViewById<Button>(R.id.sign_up)
        signUpButton.setOnClickListener{
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }


        val loginInButton = findViewById<Button>(R.id.login_in)
        loginInButton.setOnClickListener{
            val userDao = AppDatabase.getInstance(applicationContext).userDataDao()
            val userRepository = UserRepository(userDao)
            loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)
            e_mail = findViewById<EditText>(R.id.e_mail)
            password = findViewById<EditText>(R.id.password)

            val email = e_mail.text.toString().trim()
            val password = password.text.toString().trim()


            if (email.isEmpty()
                || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
            else {
                loginViewModel.loginUser(email, password).observe(this) { signInUser ->
                    if (signInUser) {
                        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                        lifecycleScope.launch {
                            val userId = loginViewModel.getUserIdByEmail(email)
                            val sharedId = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
                            val editor = sharedId.edit()
                            editor.putInt("userId", userId) // store the user ID in SharedPreferences
                            editor.putString("email",email)
                            editor.putString("password",password)
                            editor.apply()
                        }
                        val intent = Intent(this, HomeActivity::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Add any necessary clean-up code here
    }
}
