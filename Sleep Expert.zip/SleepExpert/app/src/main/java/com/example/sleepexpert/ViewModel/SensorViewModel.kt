package com.example.sleepexpert.ViewModel

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.*
import com.example.sleepexpert.View.Humidity
import com.example.sleepexpert.View.Lightness
import com.example.sleepexpert.View.Temperature

class SensorViewModel(application: Application): AndroidViewModel(application) {

    private var temperature: Temperature = Temperature(application)
    private var lightness: Lightness = Lightness(application)
    private var humidity: Humidity = Humidity(application)
    private lateinit var refreshHandler: Handler

    /**
     * Calls the needed sensor class to start monitoring the sensor data
     */
    fun startSensing() {
        temperature.startTemperatureSensing()
        lightness.startLightnessSensing()
        humidity.startHumiditySensing()
    }

    /**
     * Calls the needed sensor class to stop monitoring the sensor data
     */
    fun stopSensing() {
        temperature.stopTemperatureSensing()
        lightness.stopLightnessSensing()
        humidity.stopHumiditySensing()
    }

    /**
     * Func that exposes the pressure as LiveData to the View object
     * @return
     */
    fun retrieveTemperatureData(): LiveData<Float> {
        val temperatureValue = MutableLiveData<Float>()
        val refreshHandler = Handler(Looper.getMainLooper())
        val refreshRunnable = object : Runnable {
            override fun run() {
                refreshHandler.postDelayed(this, 5000)
                temperatureValue.value = temperature.temperatureReading.value
            }
        }
        refreshHandler.post(refreshRunnable)
        return temperatureValue
    }

    fun retrieveLightData(): LiveData<Float>{
        val lightValue = MutableLiveData<Float>()
        val refreshHandler = Handler(Looper.getMainLooper())
        val refreshRunnable = object : Runnable {
            override fun run() {
                refreshHandler.postDelayed(this, 5000)
                lightValue.value = lightness.lightnessReading.value
            }
        }
        refreshHandler.post(refreshRunnable)
        return lightValue
    }

    fun retrieveHumidityData(): LiveData<Float>{
        val humidityValue = MutableLiveData<Float>()
        val refreshHandler = Handler(Looper.getMainLooper())
        val refreshRunnable = object : Runnable {
            override fun run() {
                refreshHandler.postDelayed(this, 5000)
                humidityValue.value = humidity.humidityReading.value
            }
        }
        refreshHandler.post(refreshRunnable)
        return humidityValue
    }
}

class SensorViewModelFactory(private val applicationContext: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SensorViewModel::class.java)) {
            return SensorViewModel(applicationContext) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
