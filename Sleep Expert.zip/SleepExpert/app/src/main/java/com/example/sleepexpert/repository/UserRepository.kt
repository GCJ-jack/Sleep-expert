package com.example.sleepexpert.repository

import com.example.sleepexpert.database.User
import com.example.sleepexpert.database.UserDao
import com.example.sleepexpert.model.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class UserRepository(private val userdao: UserDao) {



    suspend fun registerUser(user: user) {
        userdao.insert(user.asDatabaseEntity())
    }

    suspend fun getUser(email: String, password: String): User?
    {return withContext(Dispatchers.IO)
    { userdao.getUserByEmailAndPassword(email, password)}
    }

    suspend fun getUserIdByEmail(email: String): Int
    {return withContext(Dispatchers.IO)
    {userdao.getUserIdByEmail(email)}
    }

    suspend fun getUserNameById(id: Int): String
    {return withContext(Dispatchers.IO)
    {userdao.getUserNameById(id)}
    }

    suspend fun updateReminder(sleepReminder: String?, sleepTarget: Double?,wakeupAlarm: String?,id: Int){
        userdao.updateAllTheReminder(sleepReminder,sleepTarget,wakeupAlarm,id)
    }

    suspend fun readSleepReminder(id: Int):String?{
        return withContext(Dispatchers.IO)
        {userdao.readSleepReminder(id)}
    }

    suspend fun readSleepTarget(id: Int):Double?{
        return withContext(Dispatchers.IO)
        {userdao.readSleepTarget(id)}
    }

    suspend fun readAlarmTime(id: Int):String?{
        return withContext(Dispatchers.IO)
        {userdao.readAlarmTime(id)}
    }

    suspend fun update(user: user){
        userdao.update(user.asDatabaseEntity())
    }





    /**
     * The version of the above function that handles a collection
     */
    fun user.asDatabaseEntity(): User{
        return User(
            id = id,
            fullName = name,
            email = email,
            password = password
        )
    }
}