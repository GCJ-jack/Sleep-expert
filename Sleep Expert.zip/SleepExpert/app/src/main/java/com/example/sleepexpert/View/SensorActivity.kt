package com.example.sleepexpert.View

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Chronometer
import android.widget.ImageButton
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.SensorViewModel
import com.example.sleepexpert.ViewModel.SensorViewModelFactory
import com.example.sleepexpert.ViewModel.SleepDiaryViewModel
import com.example.sleepexpert.model.Diary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class SensorActivity:AppCompatActivity() {
    private var sensorViewModel: SensorViewModel? = null
    private var sleepDiaryViewModel: SleepDiaryViewModel? = null
    private lateinit var stopBtn: ImageButton
    private lateinit var temperature: TextView
    private lateinit var lightness: TextView
    private lateinit var humidity: TextView
    private lateinit var chronometer: Chronometer
    private var temperatureFloat: Float = 0.0f
    private var lightnessFloat: Float = 0.0f
    private var humidityFloat: Float = 0.0f
    private lateinit var serviceIntent: Intent
    private var rollOverCount = 0
    private lateinit var deleteBtn: Button

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensor)

        showInformation()
        serviceIntent = Intent(this, SensorService::class.java)
        startService(serviceIntent)

        val filter = IntentFilter("com.example.sleepexpert.View")
        registerReceiver(receiver, filter)

        val sharedId = this.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedId.getInt("userId", -1)
        val sharedPref = this.getSharedPreferences("my_pref", Context.MODE_PRIVATE)
        val startTime = sharedPref.getString("start_time_key", "default_value")?: ""

        temperature = findViewById(R.id.temperature)
        lightness =  findViewById(R.id.lightness)
        humidity = findViewById(R.id.humidity)



        var temperatureSum = 0.0
        var temperatureCount = 0
        var averageTemperature = 0.0


        // Get a new or existing ViewModel using the ViewModelProvider.
        this.sensorViewModel = ViewModelProvider(this, SensorViewModelFactory(application))[SensorViewModel::class.java]
        this.sleepDiaryViewModel = ViewModelProvider(this)[SleepDiaryViewModel::class.java]

        this.sensorViewModel!!.retrieveTemperatureData()!!.observe(this
        )
        //  create observer, whenever the value is changed this func will be called
        { newValue ->
            newValue?.also {
                // Uncomment line below to display the pressure data in the log
                // You may choose to change this to display the data in the view - a simple view has already been provided for this
                temperature.text = "temperature: $it °C"
                temperatureFloat = it
                temperatureSum += temperatureFloat
                temperatureCount ++
                averageTemperature = temperatureSum/temperatureCount
            }
        }


        var lightSum = 0.0
        var lightCount = 0
        var averageLight = 0.0
        this.sensorViewModel!!.retrieveLightData()!!.observe(this
        )
        //  create observer, whenever the value is changed this func will be called
        { newValue ->
            newValue?.also {
                // Uncomment line below to display the pressure data in the log
                // You may choose to change this to display the data in the view - a simple view has already been provided for this
                lightness.text = "Lightness: $it lux"
                lightnessFloat = it
                lightSum += lightnessFloat
                lightCount ++
                averageLight = lightSum/lightCount
            }
        }
//
        var humiditySum = 0.0
        var humidtyCount = 0
        var averageHumidity = 0.0
        this.sensorViewModel!!.retrieveHumidityData()!!.observe(this
        )
        //  create observer, whenever the value is changed this func will be called
        { newValue ->
            newValue?.also {
                // Uncomment line below to display the pressure data in the log
                // You may choose to change this to display the data in the view - a simple view has already been provided for this
                humidity.text = "Humidity: $it %"
                humidityFloat = it
                humiditySum += humidityFloat
                humidtyCount ++
                averageHumidity = humiditySum/humidtyCount
            }
        }



        stopBtn = findViewById(R.id.stop)
        stopBtn.setOnClickListener(){
            sensorViewModel!!.stopSensing()
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
            val endTime = LocalDateTime.now().format(formatter)
            var score = 130 - rollOverCount
            if (score>100){
                score = 100
            }else if (score<0){
                score = 0
            }
            val diary = Diary(userId = userId, startTime = startTime, endTime = endTime, duration = chronometer.text.toString(), temperature = averageTemperature.toLong(), lightness = averageLight.toLong(), humidity = averageHumidity.toFloat(), score = score)
            GlobalScope.launch {
                sleepDiaryViewModel!!.createDiary(diary)
                withContext(Dispatchers.Main) {
                    val intent = Intent(this@SensorActivity, HomeActivity::class.java)
                    startActivity(intent)
                }
            }
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        // if the sensor monitoring was not manually stopped, but manually started, restart it
        this.sensorViewModel?.startSensing()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopService(serviceIntent)
        // Release any resources or perform any cleanup tasks here
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Update the UI here
            val time = intent.getStringExtra("time")
            val turnOverCount = intent.getIntExtra("roll_over",0)
            chronometer = findViewById(R.id.timer)
            chronometer.text = time
            rollOverCount = turnOverCount
        }
    }

    private fun showInformation(){
        val dialogView = LayoutInflater.from(this).inflate(R.layout.activity_detection_guideline, null)
        val infoDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()
        dialogView.findViewById<Button>(R.id.close_button).setOnClickListener {
            infoDialog.dismiss()
        }

        infoDialog.show()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, IntentFilter("com.example.sleepexpert.View"))
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
}