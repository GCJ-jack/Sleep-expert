package com.example.sleepexpert.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.sleepexpert.database.SleepDiary
import com.example.sleepexpert.database.SleepDiaryDao
import com.example.sleepexpert.model.Diary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SleepDiaryRepository(private val sleepDiaryDao: SleepDiaryDao) {

    suspend fun insert(diary: Diary) {
        sleepDiaryDao.insert(diary.asDatabaseEntity())
    }


    suspend fun getAllDiaries(userId: Int): LiveData<List<Diary>> {
        val sleepDiaryList = sleepDiaryDao.getSleepDiaries(userId)
        val diaryList = MutableLiveData<List<Diary>>()
        diaryList.postValue(sleepDiaryList.map { it.asDomainModel() })
        return diaryList
    }

    suspend fun getDiaryById(diaryId: Int): Diary? {
        val sleepDiary = sleepDiaryDao.getSleepDiaryById(diaryId)
        return sleepDiary?.asDomainModel()
    }

    suspend fun getLastSevenDuration(userId: Int): List<String>{
        return sleepDiaryDao.getLastSevenDuration(userId)
    }

    suspend fun getLastSevenDate(userId: Int): List<String>{
        return sleepDiaryDao.getLastSevenDate(userId)
    }

    suspend fun getLastWakeUpTime(userId: Int): List<String>{
        return sleepDiaryDao.getLastWakeUpTime(userId)
    }

    suspend fun getLastSevenLightLevel(userId: Int): List<Long>{
        return sleepDiaryDao.getLastSevenLightLevel(userId)
    }

    suspend fun getLastSevenTemperatureLevel(userId: Int): List<Long>{
        return sleepDiaryDao.getLastSevenTemperatureLevel(userId)
    }

    suspend fun getLastSevenHumidityLevel(userId: Int): List<Float>{
        return sleepDiaryDao.getLastSevenHumidityLevel(userId)
    }

    suspend fun getSleepDiarySize(userId: Int): Int{
        return sleepDiaryDao.getSleepDiaryCount(userId)
    }
    
    suspend fun getAllSleepDuration(userId: Int): List<String>{
        val allDuration = sleepDiaryDao.getAllTheDuration(userId)
        val duratinoList = mutableListOf<String>()
        for (duration in allDuration){
            duratinoList.add(duration)
        }
        return duratinoList
    }

    suspend fun delete(diary: Diary) {
        sleepDiaryDao.delete(diary.asDatabaseEntity())
    }

    /**
     * The version of the above function that handles a collection
     */
    fun Diary.asDatabaseEntity(): SleepDiary {
        return SleepDiary(
            userId =userId,
            score = score,
            diaryId = diaryId,
            startTime = startTime,
            endTime = endTime,
            duration = duration,
            temperature = temperature,
            lightness = lightness,
            humidity = humidity
        )
    }



    fun SleepDiary.asDomainModel(): Diary {
        return Diary(
            userId = userId?: 0,
            score = score,
            diaryId = diaryId,
            startTime = startTime,
            endTime = endTime,
            duration = duration,
            temperature = temperature,
            lightness = lightness,
            humidity = humidity
        )
    }


}