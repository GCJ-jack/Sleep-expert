package com.example.sleepexpert.View

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.RegisterViewModel
import com.example.sleepexpert.model.user

class SignUpActivity : AppCompatActivity() {
    private lateinit var registerViewModel: RegisterViewModel
    private lateinit var registerButton: Button
    private lateinit var fullNameText:EditText
    private lateinit var emailText: EditText
    private lateinit var passwordText: EditText
    private lateinit var confirmPassword: EditText
    private lateinit var signIn: TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        println("Hello")
        registerViewModel = ViewModelProvider(this).get(RegisterViewModel::class.java)
        registerViewModel.user.observe(this, Observer { user-> })
        registerButton = findViewById<Button>(R.id.registerButton)

        fullNameText = findViewById<EditText>(R.id.fullnameText)
        emailText = findViewById<EditText>(R.id.emailText)
        passwordText = findViewById<EditText>(R.id.passwordText)
        confirmPassword = findViewById(R.id.rectangle_5)
        signIn = findViewById(R.id.sign_in)
        signIn.setOnClickListener(){
            val intent = Intent(this,SignInActivity::class.java)
            startActivity(intent)
            finish()
        }
        registerButton.setOnClickListener(){
            if (fullNameText.text.toString().isEmpty()){
                fullNameText.error = "Full name is required."
                fullNameText.requestFocus()
                return@setOnClickListener
            }

            if(emailText.text.toString().isEmpty()){
                emailText.error = "Email is required."
                emailText.requestFocus()
                return@setOnClickListener
            }


            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailText.text.toString()).matches()) {
                emailText.error = "Invalid email format."
                emailText.requestFocus()
                return@setOnClickListener
            }


            if (confirmPassword.text.toString().isEmpty()) {
                confirmPassword.error = "Confirm password is required."
                confirmPassword.requestFocus()
                return@setOnClickListener
            }

            if (passwordText.text.toString().length < 6) {
                passwordText.error = "Password should be at least 6 characters long."
                passwordText.requestFocus()
                return@setOnClickListener
            }

            if (passwordText.text.toString() != confirmPassword.text.toString()) {
                confirmPassword.error = "Password doesn't match."
                confirmPassword.requestFocus()
                return@setOnClickListener
            }

            val user = user(
                name = fullNameText.text.toString(),
                email = emailText.text.toString(),
                password = passwordText.text.toString()
            )
            registerViewModel.registerUser(user)
            val intent = Intent(this,SignInActivity::class.java)
            startActivity(intent)
            finish()
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        finish()
    }

}