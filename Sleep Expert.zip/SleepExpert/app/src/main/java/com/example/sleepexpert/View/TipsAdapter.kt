package com.example.sleepexpert.View

import com.example.sleepexpert.R
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


class TipsAdapter(private val applicationContext: Context, private val topic: Array<String>, private val picture: IntArray) : BaseAdapter() {


    override fun getCount(): Int {
        return topic.size
    }

    override fun getItem(position: Int): Any {
        return topic[position] as Any
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }


    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(applicationContext).inflate(R.layout.tips_list, parent, false)
        var tipTitle = view?.findViewById<TextView>(R.id.topic)
        val icon = view?.findViewById<ImageView>(R.id.icon)
        tipTitle?.text = topic[position]
        icon?.setImageResource(picture[position])
        return view!!
    }
}