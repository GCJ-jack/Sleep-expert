package com.example.sleepexpert.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "sleepDiary",
    foreignKeys = [ForeignKey(
    entity = User::class,
    childColumns = ["user_id"],
    parentColumns = ["id"]
)])
data class SleepDiary(
    @PrimaryKey(autoGenerate = true) var diaryId: Int = 0,
    @ColumnInfo(name = "user_id") val userId: Int?,
    @ColumnInfo(name = "score") val score: Int,
    @ColumnInfo(name="start_time") var startTime: String,
    @ColumnInfo(name = "end_time") var endTime: String,
    @ColumnInfo(name= "duration") var duration: String,
    @ColumnInfo(name= "temperature") var temperature: Long,
    @ColumnInfo(name= "light") var lightness: Long,
    @ColumnInfo(name="humidity") var humidity: Float
){}
