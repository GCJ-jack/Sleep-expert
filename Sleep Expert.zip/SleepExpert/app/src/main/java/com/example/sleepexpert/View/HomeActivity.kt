package com.example.sleepexpert.View

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.add
import androidx.fragment.app.commit
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.repository.UserRepository
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity: AppCompatActivity()  {
    private lateinit var loginViewModel: LoginViewModel

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        val userDao = AppDatabase.getInstance(applicationContext).userDataDao()
        val userRepository = UserRepository(userDao)
        loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)
        val sharedPref = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("userId", -1)
        lifecycleScope.launch {
            var reminderTimeStr = loginViewModel.getSleepReminder(userId).toString()
            val calendar = Calendar.getInstance()
            val dividedTime = reminderTimeStr.split(":")
            val hourPart = dividedTime[0].toInt()
            val minutePart = dividedTime[1].substring(0, 2).toInt()
            calendar.set(Calendar.HOUR_OF_DAY, hourPart)
            calendar.set(Calendar.MINUTE, minutePart)
            calendar.set(Calendar.SECOND, 0)
            if (System.currentTimeMillis() > calendar.timeInMillis) {
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(this@HomeActivity, SleepReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                this@HomeActivity,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE // or PendingIntent.FLAG_MUTABLE
            )
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
        }

        lifecycleScope.launch {
            var alarmTimeStr = loginViewModel.getAlarmTime(userId).toString()
            val sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            sharedPref.edit().putString("alarmTime", alarmTimeStr).apply()
            val serviceIntent = Intent(this@HomeActivity, AlarmService::class.java)
            startService(serviceIntent)
        }
        val navController = findNavController(R.id.nav_host_fragment)
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.sleep -> {
                    navController.navigate(R.id.navigation_detection)
                    true
                }
                R.id.meditation -> {
                    navController.navigate(R.id.navigation_meditation)
                    true
                }
                R.id.diary -> {
                    navController.navigate(R.id.navigation_history)
                    true
                }
                R.id.personal -> {
                    navController.navigate(R.id.navigation_setting)
                    true
                }
                else -> false
            }
        }

    }
    override fun onPause() {
        super.onPause()
    }
}