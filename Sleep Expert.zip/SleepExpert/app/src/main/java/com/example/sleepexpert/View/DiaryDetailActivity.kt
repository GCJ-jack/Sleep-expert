package com.example.sleepexpert.View

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.SleepDiaryViewModel
import com.example.sleepexpert.model.Diary
import kotlinx.coroutines.launch
import org.w3c.dom.Text

class DiaryDetailActivity : AppCompatActivity() {


    private lateinit var returnBtn: Button
    private lateinit var score: TextView
    private lateinit var duration: TextView
    private lateinit var startTime: TextView
    private lateinit var endTIme: TextView
    private lateinit var brightness: TextView
    private lateinit var humidity: TextView
    private lateinit var temperature: TextView
    private lateinit var lightfeeback: TextView
    private lateinit var humidityfeeback: TextView
    private lateinit var temperaturefeeback: TextView
    private lateinit var lightsupportlink: TextView
    private lateinit var humiditysupportlink: TextView
    private lateinit var temperaturesupportlink: TextView
    private lateinit var durationLink: TextView
    private lateinit var deleteBtn: Button
    private lateinit var target:TextView
    private lateinit var targetFeeback: TextView
    private lateinit var sharedId: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.diary_detail)
        showInformation()
        val diaryId = intent.getIntExtra("diaryID", -1)

        val sleepDiaryViewModel = ViewModelProvider(this).get(SleepDiaryViewModel::class.java)
        sharedId = this.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)

        returnBtn = findViewById(R.id.return_btn)
        duration = findViewById(R.id.duration)
        score = findViewById(R.id.number)
        startTime = findViewById(R.id.start_time)
        endTIme = findViewById(R.id.wake_up_time)
        brightness = findViewById(R.id.lightness)
        humidity = findViewById(R.id.humidity_value)
        temperature = findViewById(R.id.temperature_value)
        lightfeeback = findViewById(R.id.light_feeback)
        humidityfeeback = findViewById(R.id.humidity_feeback)
        temperaturefeeback = findViewById(R.id.temperature_feeback)
        lightsupportlink = findViewById(R.id.light_feeback_link)
        humiditysupportlink= findViewById(R.id.humidity_feeback_link)
        temperaturesupportlink = findViewById(R.id.temperature_feeback_link)
        durationLink = findViewById(R.id.sleep_duration_link)
        deleteBtn = findViewById(R.id.delete_btn)
        target = findViewById(R.id.target)
        targetFeeback = findViewById(R.id.target_feeback)



        returnBtn.setOnClickListener(){
            val intent = Intent(this,SleepHistory::class.java)
            startActivity(intent)
        }

        durationLink.setOnClickListener(){
            val uri = Uri.parse("https://www.sleepfoundation.org/how-sleep-works/how-much-sleep-do-we-really-need")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }

        deleteBtn.setOnClickListener(){
            lifecycleScope.launch {
                val diary =  sleepDiaryViewModel.getDiaryById(diaryId)
                if (diary != null) {
                    sleepDiaryViewModel.delete(diary)
                }
            }
        }

        lifecycleScope.launch {
            val diary =  sleepDiaryViewModel.getDiaryById(diaryId)
            duration.text = "duration: " + diary?.duration

            val parts = diary?.duration?.split(":")
            val hours = parts?.get(0)?.toDouble()
            val minutes = (parts?.get(1)?.toDouble())?.div(60)
            val seconds = (parts?.get(2)?.toDouble())?.div(3600)
            val sumTime = hours?.plus(minutes ?: 0.0)?.plus(seconds ?: 0.0)
            val retrievedTarget = sharedId.getInt("target", 0)

            target.text = "Your sleep target "+ retrievedTarget + "hours"

            if (sumTime != null) {
                if (sumTime>=retrievedTarget){
                    targetFeeback.text = "You reach the target!"
                    targetFeeback.setTextColor(Color.GREEN)
                }
            val time1 = diary?.startTime?.substring(11)
            startTime.text = "start time: " + time1
            val time2 = diary?.endTime?.substring(11)
            endTIme.text = "end_time: " + time2
            score.text = diary?.score.toString()

            brightness.text = "Brightness: "+ diary?.lightness.toString()
            humidity.text = "Humidity level: " +diary?.humidity.toString() + " %"
            temperature.text = "Room temperature: "+ diary?.temperature.toString() + " °C"

            if (diary?.lightness!! > 200){
                lightfeeback.text = "The room may be too bright for optimal sleep quality. Consider reducing the amount of light in your sleep environment."
                lightsupportlink.text = "suggest resource link: https://www.sleepfoundation.org/bedroom-environment/making-your-room-dark"
                lightsupportlink.setOnClickListener(){
                    val url = "https://www.sleepfoundation.org/bedroom-environment/making-your-room-dark"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            } else if (diary.lightness < 200) {
                lightfeeback.text = "The light in your sleep environment is at a good level for optimal sleep quality."
            }

            if (diary.humidity in 30.0..50.0){
                humidityfeeback.text = "The humidity is in the ideal range for health and comfort."
            } else if (diary.humidity < 30.0){
                humidityfeeback.text = "The humidity is too low, which may cause dry skin, throat, and nasal passages."
                humiditysupportlink.text = "suggest resource link: https://www.novakheating.com/humidity-sleep-problems/"
                humiditysupportlink.setOnClickListener {
                    val url = "https://www.novakheating.com/humidity-sleep-problems/"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            } else if (diary.humidity> 50.0){
                humidityfeeback.text = "The humidity is too high, which may cause mold growth, respiratory problems, and allergies."
                humiditysupportlink.text = "suggest resource link: https://www.sleepfoundation.org/bedroom-environment/humidity-and-sleep"
                humiditysupportlink.setOnClickListener {
                    val url = "https://www.sleepfoundation.org/bedroom-environment/humidity-and-sleep"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            }

            if (diary.temperature >= 15.6 && diary.temperature <= 19.4 ){
                temperaturefeeback.text = "Temperature is in the recommended range for comfortable sleep."
            } else if(diary.temperature<15.6){
                temperaturefeeback.text = "Temperature is too low for comfortable sleep."
                temperaturesupportlink.text = "suggest resource link: https://www.sleepfoundation.org/best-mattress-pads/best-heated-mattress-pad"
                temperaturesupportlink.setOnClickListener {
                    val url = "https://www.sleepfoundation.org/best-mattress-pads/best-heated-mattress-pad"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            } else if(diary.temperature>19.5){
                temperaturefeeback.text = "Temperature is too high for comfortable sleep."
                temperaturesupportlink.text = "suggest resource link: https://www.sleepfoundation.org/best-mattress/best-cooling-mattress"
                temperaturesupportlink.setOnClickListener {
                    val url = "https://www.sleepfoundation.org/best-mattress/best-cooling-mattress"
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            }
        }
    }
    }
    fun showInformation(){
        val dialogView = LayoutInflater.from(this).inflate(R.layout.report_information, null)
        val infoDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()
        dialogView.findViewById<Button>(R.id.btn_close).setOnClickListener {
            infoDialog.dismiss()
        }
        dialogView.findViewById<TextView>(R.id.link).apply{
            text = "Click here to see more information about why you toss over frequently during sleep"
            setOnClickListener() {
                val url = "https://www.eightsleep.com/blog/why-we-toss-and-turn-at-night/"
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse(url)
                startActivity(intent)
            }
        }
        infoDialog.show()
    }




    override fun onDestroy() {
        super.onDestroy()
        finish()
    }
}

