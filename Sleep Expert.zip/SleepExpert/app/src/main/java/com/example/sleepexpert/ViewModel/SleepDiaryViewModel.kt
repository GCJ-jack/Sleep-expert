package com.example.sleepexpert.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.room.Room
import com.example.sleepexpert.UserApplication
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.database.SleepDiary
import com.example.sleepexpert.model.Diary
import com.example.sleepexpert.repository.SleepDiaryRepository
import com.example.sleepexpert.repository.UserRepository

class SleepDiaryViewModel(application: Application): AndroidViewModel(application)  {

    private var diaryRepository: SleepDiaryRepository

    // Method to register the user
    init {
        val database = Room.databaseBuilder(
            application,
            AppDatabase::class.java, "Sleep"
        ).build()
        diaryRepository = SleepDiaryRepository(database.diaryDao())
    }

    suspend fun createDiary(diary: Diary){
        diaryRepository.insert(diary)
    }

    suspend fun getSleepDiaries(userId: Int): LiveData<List<Diary>> {
        return diaryRepository.getAllDiaries(userId)
    }

    suspend fun getDiaryById(diaryId: Int): Diary?{
        return diaryRepository.getDiaryById(diaryId)
    }

    suspend fun getLastSevenDuration(userId: Int): List<String>{
        return diaryRepository.getLastSevenDuration(userId)
    }

    suspend fun getLastSevenDate(userId: Int): List<String>{
        return diaryRepository.getLastSevenDate(userId)
    }

    suspend fun getLastWakeUpTime(userId: Int): List<String>{
        return diaryRepository.getLastWakeUpTime(userId)
    }

    suspend fun getLastSevenLightLevel(userId: Int): List<Long>{
        return diaryRepository.getLastSevenLightLevel(userId)
    }

    suspend fun getLastSevenTemperatureLevel(userId: Int): List<Long>{
        return diaryRepository.getLastSevenTemperatureLevel(userId)
    }

    suspend fun getLastSevenHumidityLevel(userId: Int): List<Float>{
        return diaryRepository.getLastSevenHumidityLevel(userId)
    }

    suspend fun getSleepDiarySize(userId: Int):Int{
        return diaryRepository.getSleepDiarySize(userId)
    }

    suspend fun getAllDuration(userId: Int): List<String>{
        return diaryRepository.getAllSleepDuration(userId)
    }

    suspend fun delete(diary: Diary){
        diaryRepository.delete(diary)
    }

}