package com.example.sleepexpert.View

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.example.sleepexpert.R

class MusicService : Service() {

    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var handler: Handler
    private var isTracking = false

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                createNotificationChannel()
            } else {
                ""
            }

        val notificationIntent = Intent(this, PlayerActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            1,
            intent,
            PendingIntent.FLAG_IMMUTABLE // or PendingIntent.FLAG_MUTABLE
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Music Service")
            .setContentText("Playing music...")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .build()

//        startForeground(1, notification)

        val sharedPref = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val musicUrl = sharedPref.getString("musicUrl", null)
        mediaPlayer = MediaPlayer()
        mediaPlayer.setDataSource(musicUrl)
        mediaPlayer.isLooping = true
        mediaPlayer.setOnCompletionListener {
//            seekBar.progress = 0
        }
        mediaPlayer.prepareAsync()
        mediaPlayer.setOnPreparedListener {
            mediaPlayer.start()
//            seekBar.max = mediaPlayer.duration
        }

        handler = Handler(Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                try {
                    if (mediaPlayer != null&&mediaPlayer.isPlaying && !isTracking) {
                        val progress = mediaPlayer.currentPosition
//                        seekBar.progress = progress
                    }
                    handler.postDelayed(this, 1000)
                } catch (e: IllegalStateException){
                }
            }
        })

        return START_STICKY
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        handler.removeCallbacksAndMessages(null)
        stopForeground(Service.STOP_FOREGROUND_REMOVE)

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel(): String {
        val channelId = "Music Service Channel"
        val channelName = "Music Service Channel"
        val channel = NotificationChannel(
            channelId, channelName, NotificationManager.IMPORTANCE_LOW
        )
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
        return channelId
    }
}
