package com.example.sleepexpert.View

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.sleepexpert.R

class PlayerActivity: AppCompatActivity() {

    private lateinit var forwardBtn: View
    private lateinit var backwardBtn: View
    private lateinit var pauseBtn: View
    private lateinit var seekBar: SeekBar
    private lateinit var returnButton: View
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var handler: Handler
    private var isTracking = false


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)

        returnButton = findViewById(R.id.return_btn)
        returnButton.setOnClickListener(){
            intent = Intent(this,HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

        seekBar = findViewById<SeekBar>(R.id.sb)
        seekBar.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                isTracking = true
            }
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                isTracking = false
            }
        })

        forwardBtn = findViewById<View>(R.id.forwardBtn)
        forwardBtn.setOnClickListener(){
            if(mediaPlayer.isPlaying) {
                val currentPosition = mediaPlayer.currentPosition
                mediaPlayer.seekTo(currentPosition + 5000)
                mediaPlayer.setOnCompletionListener {
                    seekBar.progress = mediaPlayer.currentPosition
                }
            }
        }

        backwardBtn = findViewById<View>(R.id.backwardBtn)
        backwardBtn.setOnClickListener(){
            if(mediaPlayer.isPlaying) {
                val currentPosition = mediaPlayer.currentPosition
                mediaPlayer.seekTo(currentPosition - 5000)
                mediaPlayer.setOnCompletionListener {
                    seekBar.progress = mediaPlayer.currentPosition
                }
            }

        }

        pauseBtn = findViewById<ImageButton>(R.id.pause_btn)

        pauseBtn.setOnClickListener(){
            if(mediaPlayer.isPlaying){
                mediaPlayer.pause()
                pauseBtn.setBackgroundResource(R.drawable.playbutton)
            } else{
                mediaPlayer.start()
                pauseBtn.setBackgroundResource(R.drawable.img_9)
            }
        }

        handler = Handler(Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                try {
                    if (mediaPlayer != null&&mediaPlayer.isPlaying && !isTracking) {
                        val progress = mediaPlayer.currentPosition
                        seekBar.progress = progress
                    }
                    handler.postDelayed(this, 1000)
                } catch (e: IllegalStateException){
                }
            }
        })
    }


    override fun onStart() {
        super.onStart()
        val sharedPref = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val musicUrl = sharedPref.getString("musicUrl", null)
        mediaPlayer = MediaPlayer()
        mediaPlayer.setDataSource(musicUrl)
        println("play music")
        mediaPlayer.isLooping = true
        mediaPlayer.setOnCompletionListener {
            pauseBtn.setBackgroundResource(R.drawable.playbutton)
            seekBar.progress = 0
        }
        mediaPlayer.prepareAsync()
        mediaPlayer.setOnPreparedListener {
            mediaPlayer.start()
            seekBar.max = mediaPlayer.duration
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        handler.removeCallbacksAndMessages(null)
        finish()
    }

    override fun onStop() {
        super.onStop()
        mediaPlayer.stop()
        mediaPlayer.release()
    }
}
