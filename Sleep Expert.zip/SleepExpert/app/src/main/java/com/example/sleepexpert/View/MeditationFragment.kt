package com.example.sleepexpert.View

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.MediaStore.Audio
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.databinding.DataBindingUtil.setContentView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.ViewModel.SensorViewModel
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.launch

class MeditationFragment: Fragment(R.layout.activity_meditation) {
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var sleepMusic: View
    private lateinit var guideOne: View
    private lateinit var guideTwo: View
    private lateinit var guideThree: View
    private lateinit var guideFour: View
    private lateinit var riverMusic: View
    private lateinit var cafeMusic: View
    private lateinit var rainDropMusic: View
    private lateinit var studyMusic: View
    private lateinit var userName: TextView



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the fragment's layout
        val view = inflater.inflate(R.layout.activity_meditation, container, false)

        val sharedPref = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("userId", -1)
        val userDao = AppDatabase.getInstance(requireContext()).userDataDao()
        val userRepository = UserRepository(userDao)
        loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)
        userName = view.findViewById(R.id.id)
        lifecycleScope.launch {
            userName.text = loginViewModel.getUserNameById(userId)
        }

        // Find the TextView by ID
        sleepMusic = view.findViewById(R.id.sleepmusic)
        sleepMusic.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl", "https://episodes.castos.com/5f7c81b7a6e236-95140552/twb-01-love-stillness-guided-meditate.mp3")
            editor.apply()
            startActivity(intent)
        }

        guideOne = view.findViewById(R.id.guide1)
        guideOne.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl", "https://episodes.castos.com/5f7c81b7a6e236-95140552/twb-02-sacred-space-guided-meditate.mp3")
            editor.apply()
            startActivity(intent)
        }

        guideTwo = view.findViewById(R.id.guide2)
        guideTwo.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl", "https://episodes.castos.com/5f7c81b7a6e236-95140552/twb-05-circular-breath-guided-meditate.mp3")
            editor.apply()
            startActivity(intent)
        }

        guideThree = view.findViewById(R.id.guide3)
        guideThree.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl", "https://episodes.castos.com/5f7c81b7a6e236-95140552/twb-12-ease-guided-meditate.mp3")
            editor.apply()
            startActivity(intent)
        }

        guideFour = view.findViewById(R.id.guide4)
        guideFour.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl","https://episodes.castos.com/5f7c81b7a6e236-95140552/twb-17-in-the-moment-guided-meditate.mp3")
            editor.apply()
            startActivity(intent)
        }

        riverMusic = view.findViewById(R.id.river_sound)
        riverMusic.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl","https://www.soundjay.com/nature/sounds/river-1.mp3")
            editor.apply()
            startActivity(intent)
        }

        cafeMusic = view.findViewById(R.id.coffee_shop_sound)
        cafeMusic.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl","https://www.soundjay.com/nature/sounds/rain-01.mp3")
            editor.apply()
            startActivity(intent)
        }
        rainDropMusic = view.findViewById(R.id.rain_drop_sound)
        rainDropMusic.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl","https://www.soundjay.com/nature/sounds/rain-01.mp3")
            editor.apply()
            startActivity(intent)
        }
        studyMusic = view.findViewById(R.id.study_sound)
        studyMusic.setOnClickListener(){
            val intent = Intent(activity,PlayerActivity::class.java)
            val sharedPref = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("musicUrl","https://www.soundjay.com/nature/sounds/rain-01.mp3")
            editor.apply()
            startActivity(intent)
        }

        return view
    }

    override fun onResume() {
        super.onResume()
    }



    override fun onDestroy() {
        super.onDestroy()
    }
}