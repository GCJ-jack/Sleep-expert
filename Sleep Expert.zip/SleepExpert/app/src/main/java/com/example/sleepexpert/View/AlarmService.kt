package com.example.sleepexpert.View

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.example.sleepexpert.R
import java.util.*

class AlarmService: Service() {

    private lateinit var wakeLock: PowerManager.WakeLock

    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }


    override fun onCreate() {
        super.onCreate()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AlarmService::WakeLock"
        )

    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wakeLock.acquire()

        val sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val alarmTimeStr = sharedPref.getString("alarmTime", "08:00:00")?: "08:00:00"

            // Convert alarm time string to calendar instance
        val calendar = Calendar.getInstance()
        val dividedTime = alarmTimeStr.split(":")
        val hourPart = dividedTime[0].toInt()
        val minutePart = dividedTime[1].substring(0, 2).toInt()
        calendar.set(Calendar.HOUR_OF_DAY, hourPart)
        calendar.set(Calendar.MINUTE, minutePart)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND,0)

            // Set alarm
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmBroadcastReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        if (System.currentTimeMillis() > calendar.timeInMillis) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeLock.release()
    }
}