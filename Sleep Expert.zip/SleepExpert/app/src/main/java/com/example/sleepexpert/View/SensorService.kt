package com.example.sleepexpert.View

import android.app.*
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import android.util.Log
import android.widget.Chronometer
import android.widget.RemoteViews
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.lifecycle.ViewModelProvider
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.SensorViewModel
import com.example.sleepexpert.ViewModel.SensorViewModelFactory
import java.lang.Math.abs
import kotlin.math.pow
import kotlin.math.sqrt

class SensorService: Service() {

    private lateinit var handler: Handler
    private var timeElapsed: Long = 0
    private lateinit var chronometer: Chronometer
    private lateinit var wakeLock: PowerManager.WakeLock

    private lateinit var sensorManagerGyroscope: SensorManager
    private lateinit var sensorManagerAccelerometer: SensorManager
    private lateinit var gyroscope: Sensor
    private lateinit var accelerometer: Sensor
    private var rollOverCount = 0

    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    companion object {
        private const val TAG = "SleepQualityService"
        const val ROLL_OVER_COUNT_ACTION = "uk.ac.sheffield.dcs.com31007_4510_6510.lab7"
        const val ROLL_OVER_THRESHOLD = 1f // adjust as needed
    }

    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }

    override fun onCreate() {
        super.onCreate()
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "TimerService::WakeLock"
        )
        sensorManagerGyroscope = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManagerAccelerometer = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroscope = sensorManagerGyroscope.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        accelerometer = sensorManagerAccelerometer.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManagerGyroscope.registerListener(sensorListener, gyroscope, SensorManager.SENSOR_DELAY_UI)
        sensorManagerAccelerometer.registerListener(sensorListenerAccelerometer, gyroscope, SensorManager.SENSOR_DELAY_UI)
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wakeLock.acquire()
        val channelId =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                createNotificationChannel()
            } else {
                ""
            }
        val notificationIntent = Intent(this, SensorActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            1,
            intent,
            PendingIntent.FLAG_IMMUTABLE // or PendingIntent.FLAG_MUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Diary Service")
            .setContentText("Your phone is tracking....")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .build()

        chronometer = Chronometer(applicationContext)
        chronometer.format = "00:00:00"
        handler = Handler(Looper.getMainLooper())
        handler.postDelayed(object : Runnable {
            override fun run() {
                timeElapsed += 1000
                val hours = (timeElapsed / 3600000).toInt()
                val minutes = ((timeElapsed - hours * 3600000) / 60000).toInt()
                val seconds = ((timeElapsed - hours * 3600000 - minutes * 60000) / 1000).toInt()
                chronometer.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                val intent = Intent("com.example.sleepexpert.View")
                intent.putExtra("time", chronometer.text.toString())
                intent.putExtra("roll_over",rollOverCount)
                sendBroadcast(intent)
                handler.postDelayed(this, 1000)
            }
        }, 1000)


        startForeground(1, notification)



        return START_STICKY
    }

    private val sensorListener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        override fun onSensorChanged(event: SensorEvent) {
            // process sensor data here


            val x = kotlin.math.abs(event.values[0]).let { if(it >=9.8) it-9.8 else it }.toFloat()
            val y = kotlin.math.abs(event.values[1]).let { if(it >=9.8) it-9.8 else it }.toFloat()
            val z = kotlin.math.abs(event.values[2]).let { if(it >=9.8) it-9.8 else it }.toFloat()

            var deltaX = kotlin.math.abs(lastX - x)
            var deltaY = kotlin.math.abs(lastY - y)
            var deltaZ = kotlin.math.abs(lastZ - y)


            lastX = x
            lastY = y
            lastZ = z

            if (deltaX > ROLL_OVER_THRESHOLD && deltaY > ROLL_OVER_THRESHOLD) {
                rollOverCount++
                println("roll over$rollOverCount")
            }
        }
    }

    private val sensorListenerAccelerometer = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        override fun onSensorChanged(event: SensorEvent) {
            // process sensor data here

            // Remove the Acceleration due to gravity component.
            // The alternative to this is to use Sensor.TYPE_LINEAR_ACCELERATION
            val x = kotlin.math.abs(event.values[0]).let { if(it >=9.8) it-9.8 else it }.toFloat()
            val y = kotlin.math.abs(event.values[1]).let { if(it >=9.8) it-9.8 else it }.toFloat()
            val z = kotlin.math.abs(event.values[2]).let { if(it >=9.8) it-9.8 else it }.toFloat()

            var deltaX = kotlin.math.abs(lastX - x)
            var deltaY = kotlin.math.abs(lastY - y)
            var deltaZ = kotlin.math.abs(lastZ - y)


            lastX = x
            lastY = y
            lastZ = z

            if (deltaZ > ROLL_OVER_THRESHOLD) {
                rollOverCount++
                println("roll over$rollOverCount")
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel(): String {
        val channelId = "Sensor Service Channel"
        val channelName = "Sensor Service Channel"
        val channel = NotificationChannel(
            channelId, channelName, NotificationManager.IMPORTANCE_LOW
        )
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
        return channelId
    }

    override fun onDestroy() {
        super.onDestroy()
        if (wakeLock.isHeld) {
            wakeLock.release()
        }
        rollOverCount = 0
        handler.removeCallbacksAndMessages(null)
    }


}