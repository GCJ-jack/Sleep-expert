package com.example.sleepexpert.View

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.icu.lang.UCharacter.IndicPositionalCategory.RIGHT
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.SleepDiaryViewModel
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.model.Diary
import com.example.sleepexpert.repository.SleepDiaryRepository
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SleepHistory: AppCompatActivity() {

    private lateinit var diaryAdapter: DiaryAdapter
    private lateinit var durationGraph: com.github.mikephil.charting.charts.LineChart
    private lateinit var bedTimeGraph: com.github.mikephil.charting.charts.LineChart
    private lateinit var wakeUpTimeGraph: com.github.mikephil.charting.charts.LineChart
    private lateinit var lightLineChart: com.github.mikephil.charting.charts.LineChart
    private lateinit var temperatureLineChart: com.github.mikephil.charting.charts.LineChart
    private lateinit var humidityLineChart: com.github.mikephil.charting.charts.LineChart
    private lateinit var sharedId: SharedPreferences
    private lateinit var diaryList: MutableList<Diary>

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diary_history)


        sharedId = this.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedId.getInt("userId", -1)

        val recyclerView = findViewById<RecyclerView>(R.id.diary_history_list_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        diaryList = mutableListOf()
        diaryAdapter = DiaryAdapter(this, diaryList)

        val sleepDiaryViewModel = ViewModelProvider(this).get(SleepDiaryViewModel::class.java)
        durationGraph = findViewById(R.id.duration_line_chart)
        bedTimeGraph = findViewById(R.id.start_time_line_chart)
        wakeUpTimeGraph = findViewById(R.id.end_time_line_chart)
        lightLineChart = findViewById(R.id.light_line_chart)
        temperatureLineChart = findViewById(R.id.temperature_line_chart)
        humidityLineChart = findViewById(R.id.humidity_line_chart)
        // observe the LiveData for sleep diary list
        lifecycleScope.launch {
            sleepDiaryViewModel.getSleepDiaries(userId).observe(this@SleepHistory) { sleepDiaryList ->
                diaryList.clear()
                diaryList.addAll(sleepDiaryList.reversed())
                diaryAdapter.notifyDataSetChanged()
            }

            val durationList = sleepDiaryViewModel.getLastSevenDuration(userId)
            var newDuration = mutableListOf<Double>()
            for (duration in durationList.reversed()) {
                val parts = duration.split(":")
                newDuration.add(parts[0].toDouble() + parts[1].toDouble()/ 60 + parts[2].toDouble() / 3600)
            }

            val lastSevenDaylist = sleepDiaryViewModel.getLastSevenDate(userId)
            var label = mutableListOf<String>()
            for (day in lastSevenDaylist.reversed()) {
                val parts = day.split(" ")
                label.add(parts[0])
            }

            var bed_time_label = mutableListOf<String>()
            for (day in lastSevenDaylist.reversed()) {
                val parts = day.split(" ")
                bed_time_label.add(parts[1])
            }

            val lastSevenWakeUpList = sleepDiaryViewModel.getLastWakeUpTime(userId)
            val lastSevenLightLevel = sleepDiaryViewModel.getLastSevenLightLevel(userId).reversed()
            val lastSevenTemperatureLevel = sleepDiaryViewModel.getLastSevenTemperatureLevel(userId).reversed()
            val lastSevenHumidityLevel = sleepDiaryViewModel.getLastSevenHumidityLevel(userId).reversed()
            var wake_up_time_label = mutableListOf<String>()
            for (day in lastSevenWakeUpList.reversed()) {
                val parts = day.split(" ")
                wake_up_time_label.add(parts[1])
            }

            var light_level_list = mutableListOf<Long>()
            for (day in lastSevenLightLevel) {
                light_level_list.add(day)
            }

            drawDurationGraph(durationGraph,newDuration,label)
            drawBedTimeTrendChart(bedTimeGraph,bed_time_label,label)
            drawWakeUpTimeTrendChart(wakeUpTimeGraph,wake_up_time_label,label)
            drawLightTrendChart(lightLineChart,light_level_list,label)
            drawTemperatureChart(temperatureLineChart,lastSevenTemperatureLevel,label)
            drawHumidityLevel(humidityLineChart,lastSevenHumidityLevel,label)
        }
        // Set the adapter to the list view
        recyclerView.adapter = diaryAdapter
    }

    fun drawDurationGraph(durationGraph: LineChart, durationList: List<Double>, lastSevenDay: List<String>) {
        durationGraph.description.isEnabled = false
        durationGraph.setTouchEnabled(true)
        durationGraph.setPinchZoom(true)
        durationGraph.setScaleEnabled(true)
        durationGraph.xAxis.isEnabled = true
        durationGraph.setDrawGridBackground(false)
        durationGraph.axisLeft.isEnabled = true
        durationGraph.axisLeft.setDrawGridLines(true)
        durationGraph.axisLeft.granularity = 1f
        durationGraph.axisRight.isEnabled = true
        durationGraph.xAxis.position = XAxis.XAxisPosition.BOTTOM
        val xAxis = durationGraph.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(lastSevenDay)
        xAxis.setDrawGridLines(true)
        xAxis.granularity = 1f

        val yAxis = durationGraph.axisLeft
        yAxis.setDrawGridLines(true)
        yAxis.granularity = 1f


        val entries = mutableListOf<Entry>()
        for (i in durationList.indices) {
            entries.add(Entry(i.toFloat(), durationList[i].toFloat()))
        }

        val retrievedTarget = sharedId.getInt("target", 0)

        val targetLine = LimitLine(retrievedTarget.toFloat(), "Sleep target")
        targetLine.lineWidth = 2f
        targetLine.enableDashedLine(10f, 10f, 0f)
        targetLine.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        targetLine.textSize = 10f
        durationGraph.axisLeft.addLimitLine(targetLine)

        val dataSet = LineDataSet(entries, "Duration over the last 7 days")
        dataSet.color = Color.RED
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)

        val lineData = LineData(dataSet)

        durationGraph.data = lineData
        durationGraph.invalidate()
    }


    fun drawBedTimeTrendChart(bedTimeGraph: com.github.mikephil.charting.charts.LineChart, bedTimeList: List<String>,lastSevenDay:List<String>) {
        bedTimeGraph.description.isEnabled = false
        bedTimeGraph.setTouchEnabled(true)
        bedTimeGraph.setDrawGridBackground(false)
        bedTimeGraph.setPinchZoom(true)
        bedTimeGraph.setScaleEnabled(true)
        bedTimeGraph.axisRight.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val hours = value.toInt()
                return String.format("%02d:00", hours)
            }
        }
        bedTimeGraph.xAxis.isEnabled = true
        bedTimeGraph.xAxis.position = XAxis.XAxisPosition.BOTTOM
        bedTimeGraph.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index < lastSevenDay.size) {
                    lastSevenDay[index]
                } else {
                    ""
                }
            }
        }

        // set data for the graph
        val entries = mutableListOf<Entry>()
        // populate entries with your data
        for (i in bedTimeList.indices) {
            val bedTime = bedTimeList[i]
            val parts = bedTime.split(":")
            val hours = parts[0].toFloat()
            entries.add(Entry(i.toFloat(), hours))
        }
        val dataSet = LineDataSet(entries, "Bed Time over the last 7 days")
        dataSet.color = Color.RED
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)
        val lineData = LineData(dataSet)
        bedTimeGraph.data = lineData
        bedTimeGraph.invalidate()
    }

    fun drawWakeUpTimeTrendChart(wakeUpTimeGraph: com.github.mikephil.charting.charts.LineChart, wakeUpTimeList: List<String>,lastSevenDay:List<String>){
        wakeUpTimeGraph.description.isEnabled = false
        wakeUpTimeGraph.setTouchEnabled(true)
        wakeUpTimeGraph.setDrawGridBackground(false)
        wakeUpTimeGraph.setPinchZoom(true)
        wakeUpTimeGraph.setScaleEnabled(true)
        wakeUpTimeGraph.axisRight.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val hours = value.toInt()
                return String.format("%02d:00", hours)
            }
        }
        wakeUpTimeGraph.xAxis.isEnabled = true
        wakeUpTimeGraph.xAxis.position = XAxis.XAxisPosition.BOTTOM
        wakeUpTimeGraph.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return lastSevenDay[value.toInt()]
            }
        }

        // set data for the graph
        val entries = mutableListOf<Entry>()
        // populate entries with your data
        for (i in wakeUpTimeList.indices) {
            val wakeUpTime = wakeUpTimeList[i]
            val parts = wakeUpTime.split(":")
            val hours = parts[0].toFloat()
            entries.add(Entry(i.toFloat(), hours))
        }

        val dataSet = LineDataSet(entries, "Wake up Time over the last 7 days")
        dataSet.color = Color.RED
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)
        val lineData = LineData(dataSet)
        wakeUpTimeGraph.data = lineData
        wakeUpTimeGraph.invalidate()
    }

    fun drawLightTrendChart(lightLineChart: com.github.mikephil.charting.charts.LineChart, lightLevelList: List<Long>,lastSevenDay:List<String>){
        lightLineChart.description.isEnabled = false
        lightLineChart.setTouchEnabled(true)
        lightLineChart.setDrawGridBackground(false)
        lightLineChart.setPinchZoom(true)
        lightLineChart.setScaleEnabled(true)
        lightLineChart.axisLeft.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return "$value lux"
            }
        }
        lightLineChart.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                if (index >= 0 && index < lastSevenDay.size) {
                    return lastSevenDay[index]
                }
                return ""
            }
        }
        lightLineChart.xAxis.labelCount = lastSevenDay.size
        lightLineChart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        val entries = mutableListOf<Entry>()
        for (i in lightLevelList.indices) {
            entries.add(Entry(i.toFloat(), lightLevelList[i].toFloat()))
        }

        val dataSet = LineDataSet(entries, "Light level during bedtime")
        dataSet.color = Color.BLUE
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)

        val limitLine = LimitLine(200f, "Good for sleep")
        limitLine.lineWidth = 2f
        limitLine.enableDashedLine(10f, 10f, 0f)
        limitLine.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        limitLine.textSize = 10f
        lightLineChart.axisLeft.addLimitLine(limitLine)
        val lineData = LineData(dataSet)
        lightLineChart.data = lineData
        lightLineChart.invalidate()

    }

    fun drawTemperatureChart(temperatureLineChart: com.github.mikephil.charting.charts.LineChart, temperatureLevel: List<Long>,lastSevenDay:List<String>){
        temperatureLineChart.description.isEnabled = false
        temperatureLineChart.setTouchEnabled(true)
        temperatureLineChart.setDrawGridBackground(false)
        temperatureLineChart.setPinchZoom(true)
        temperatureLineChart.setScaleEnabled(true)
        temperatureLineChart.axisLeft.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return "$value lx"
            }
        }
        temperatureLineChart.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                if (index >= 0 && index < lastSevenDay.size) {
                    return lastSevenDay[index]
                }
                return ""
            }
        }
        temperatureLineChart.xAxis.labelCount = lastSevenDay.size
        temperatureLineChart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        val entries = mutableListOf<Entry>()
        for (i in temperatureLevel.indices) {
            entries.add(Entry(i.toFloat(), temperatureLevel[i].toFloat()))
        }

        val llmin = LimitLine(15f,"min suggested temp")
        llmin.lineWidth = 2f
        llmin.enableDashedLine(10f, 10f, 0f)
        llmin.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        llmin.textSize = 10f
        temperatureLineChart.axisLeft.addLimitLine(llmin)

        val llmax = LimitLine(18f,"max suggested temp")
        llmax.lineWidth = 2f
        llmax.enableDashedLine(10f, 10f, 0f)
        llmax.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        llmax.textSize = 10f
        temperatureLineChart.axisLeft.addLimitLine(llmax)

        val dataSet = LineDataSet(entries, "Temperature level during bedtime")
        dataSet.color = Color.BLUE
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)

        val lineData = LineData(dataSet)
        temperatureLineChart.data = lineData
        temperatureLineChart.invalidate()
    }


    fun drawHumidityLevel(humidityLineChart: com.github.mikephil.charting.charts.LineChart, humidityLevelList: List<Float>,lastSevenDay:List<String>){
        humidityLineChart.description.isEnabled = false
        humidityLineChart.setTouchEnabled(true)
        humidityLineChart.setDrawGridBackground(false)
        humidityLineChart.setPinchZoom(true)
        humidityLineChart.setScaleEnabled(true)
        humidityLineChart.axisLeft.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return "$value lx"
            }
        }
        humidityLineChart.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                if (index >= 0 && index < lastSevenDay.size) {
                    return lastSevenDay[index]
                }
                return ""
            }
        }
        humidityLineChart.xAxis.labelCount = lastSevenDay.size
        humidityLineChart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        val entries = mutableListOf<Entry>()
        for (i in humidityLevelList.indices) {
            entries.add(Entry(i.toFloat(), humidityLevelList[i].toFloat()))
        }

        val llmin = LimitLine(40f,"min suggested humidity")
        llmin.lineWidth = 2f
        llmin.enableDashedLine(10f, 10f, 0f)
        llmin.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        llmin.textSize = 10f
        humidityLineChart.axisLeft.addLimitLine(llmin)

        val llmax = LimitLine(60f,"max suggested humidity")
        llmax.lineWidth = 2f
        llmax.enableDashedLine(10f, 10f, 0f)
        llmax.labelPosition = LimitLine.LimitLabelPosition.RIGHT_TOP
        llmax.textSize = 10f
        humidityLineChart.axisLeft.addLimitLine(llmax)

        val dataSet = LineDataSet(entries, "Temperature level during bedtime")
        dataSet.color = Color.BLUE
        dataSet.setDrawCircles(true)
        dataSet.setDrawCircleHole(false)
        dataSet.setDrawValues(false)

        val lineData = LineData(dataSet)
        humidityLineChart.data = lineData
        humidityLineChart.invalidate()
    }

        override fun onDestroy() {
        // Perform any cleanup or releasing of resources here
        super.onDestroy()
        finish()
    }
}




