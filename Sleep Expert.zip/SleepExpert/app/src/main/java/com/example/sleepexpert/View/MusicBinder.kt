package com.example.sleepexpert.View

import android.media.MediaPlayer
import android.os.Binder

class MusicBinder(private val mediaPlayer: MediaPlayer) : Binder() {
    fun getCurrentPosition(): Int {
        return mediaPlayer.currentPosition
    }

    fun setSeekbarProgress(progress: Int) {
        mediaPlayer.seekTo(progress)
    }
}