package com.example.sleepexpert

import android.app.Application
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import com.example.sleepexpert.ViewModel.RegisterViewModel
import com.example.sleepexpert.ViewModel.RegisterViewModelFactory

class UserAppCompatActivity:AppCompatActivity() {
    // Instantiate the ViewModel from the ImageViewModelFactory
    // which extends ViewModelProvider.Factory
    protected val registerViewModel: RegisterViewModel by viewModels {
        RegisterViewModelFactory((application as UserApplication).repository, application)
    }
}