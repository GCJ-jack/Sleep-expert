package com.example.sleepexpert.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.sleepexpert.database.SleepDiary
import java.io.Serializable

@Entity
data class Diary(@PrimaryKey(autoGenerate = true)var diaryId: Int = 0,
                 @ColumnInfo(name = "user_id") val userId: Int?,
                 @ColumnInfo(name = "score") var score: Int,
                 @ColumnInfo(name = "start_time") var startTime: String,
                 @ColumnInfo(name = "end_time") var endTime: String,
                 @ColumnInfo(name = "duration") var duration: String,
                 @ColumnInfo(name = "temperature") var temperature: Long,
                 @ColumnInfo(name = "lightness") var lightness: Long,
                 @ColumnInfo(name = "humidity") var humidity: Float
): Serializable {}







