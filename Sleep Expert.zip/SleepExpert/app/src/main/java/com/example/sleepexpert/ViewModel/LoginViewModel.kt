package com.example.sleepexpert.ViewModel

import android.app.Application
import androidx.lifecycle.*
import com.example.sleepexpert.database.User
import com.example.sleepexpert.database.UserDao
import com.example.sleepexpert.model.user
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginViewModel(private val userRepository: UserRepository): ViewModel() {

    fun loginUser(email: String, password: String):LiveData<Boolean>{
        val result = MutableLiveData<Boolean>()
        viewModelScope.launch {
            val user = userRepository.getUser(email, password)
            result.value = user != null
    }
        return result
    }

    suspend fun getUserIdByEmail(email: String):Int {
        return withContext(Dispatchers.IO) {
            userRepository.getUserIdByEmail(email)
        }
    }

    suspend fun getUserNameById(id: Int):String{
        return withContext(Dispatchers.IO) {
            userRepository.getUserNameById(id)
        }
    }

    suspend fun updateAllReminder(sleepReminder: String?, sleepTarget: Double?, wakeupAlarm: String?,id: Int){
        userRepository.updateReminder(sleepReminder,sleepTarget,wakeupAlarm,id)
    }

    suspend fun getSleepReminder(id: Int):String?{
        return withContext(Dispatchers.IO) {
            userRepository.readSleepReminder(id)
        }
    }

    suspend fun getSleepTarget(id: Int):Double?{
        return withContext(Dispatchers.IO) {
            userRepository.readSleepTarget(id)
        }
    }

    suspend fun getAlarmTime(id: Int):String?{
        return withContext(Dispatchers.IO) {
            userRepository.readAlarmTime(id)
        }
    }

    fun update(user: user) = viewModelScope.launch {
        userRepository.update(user)
    }
}

class LoginViewModelFactory(private val userRepository: UserRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LoginViewModel(userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}


