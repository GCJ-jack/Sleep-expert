package com.example.sleepexpert.View

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.model.user
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.launch

class ChangePasswordDialogFragment: DialogFragment(R.layout.change_password) {

    private lateinit var oldPassword: EditText
    private lateinit var newPassword: EditText
    private lateinit var submit: Button
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.change_password, container, false)
        val sharedPref = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("userId", -1)
        val email = sharedPref.getString("email", "")
        val sharePassword = sharedPref.getString("password","")
        oldPassword = view.findViewById(R.id.editText)
        newPassword = view.findViewById(R.id.editText2)
        submit = view.findViewById(R.id.submit)
        val userDao = AppDatabase.getInstance(requireContext()).userDataDao()
        val userRepository = UserRepository(userDao)
        loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)
        submit.setOnClickListener(){
            val passwordNew = newPassword.text.toString()
            val passwordOld = oldPassword.text.toString()

            if (passwordOld == sharePassword){
                lifecycleScope.launch{
                    val name =  loginViewModel.getUserNameById(userId)
                    loginViewModel.update(user(id = userId, email = email!!, password = passwordNew, name = name))
                    requireActivity().finish()
                }
            }else{
                Toast.makeText(requireContext(), "Invalid password", Toast.LENGTH_SHORT).show()
            }
            dismiss()
        }
        return view
    }
}