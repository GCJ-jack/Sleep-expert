package com.example.sleepexpert.View

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.util.Log
import androidx.lifecycle.MutableLiveData
import java.lang.Exception

class Humidity(context: Context) {
    private val HUMIDITY_READING_FREQ_MICRO_SEC: Int = 30000
    private var samplingRateInMicroSec: Long = HUMIDITY_READING_FREQ_MICRO_SEC.toLong()
    private var samplingRateInNanoSec: Long = samplingRateInMicroSec * 1000
    private var timePhoneWasLastRebooted: Long = 0
    private var lastReportTime: Long = 0

    private var sensorManager: SensorManager?
    private var humiditySensor: Sensor
    private var humidityEventListener: SensorEventListener? = null
    private var _isStarted = false

    val isStarted: Boolean
        get() {return _isStarted}

    var humidityReading: MutableLiveData<Float> = MutableLiveData<Float>()


    init{
        // http://androidforums.com/threads/how-to-get-time-of-last-system-boot.548661/
        timePhoneWasLastRebooted = System.currentTimeMillis() - SystemClock.elapsedRealtime()

        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        humiditySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY)!!

        /**
         * this inits the listener and establishes the actions to take when a sensor is available
         * It is not registere to listen at this point, but makes sure the object is available to
         * listen when registered.
         */
        humidityEventListener  = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {

                val actualTimeInMseconds = this@Humidity.timePhoneWasLastRebooted + (event.timestamp / 1000000.0).toLong()
                val timeString = Utilities.mSecsToString(actualTimeInMseconds)
                // In this example, only updating the LiveData (hence UI gets update),
                // when there is a new humidity value -
                if(humidityReading.value != event.values[0]){humidityReading.value = event.values[0]}
                val accuracy = event.accuracy
                Log.i(TAG,
                    Utilities.mSecsToString(actualTimeInMseconds) + ": current humidity: " + humidityReading.value + "with accuracy: " + accuracy

                )
                this@Humidity.lastReportTime = event.timestamp
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
    }

    companion object {
        private val TAG = Humidity::class.java.simpleName

        /**
         * this is used to stop the barometer if we have not seen any movement in the last 20 seconds
         */
    }

    /**
     * it starts the pressure monitoring and updates the _isStarted status flag
     * @param accelerometer
     */
    fun startHumiditySensing() {
        sensorManager?.let {
            Log.d(TAG, "Starting listener")
            it.registerListener(
                humidityEventListener,
                humiditySensor,
                SensorManager.SENSOR_DELAY_UI
            )
            _isStarted = true
        }
    }

    /**
     * this stops the barometer and updates the _isStarted status flag
     */
    fun stopHumiditySensing() {
        sensorManager?.let {
            Log.d(TAG, "Stopping listener")
            try {
                it.unregisterListener(humidityEventListener)
                _isStarted = false
            } catch (e: Exception) {
            }
        }
    }
}