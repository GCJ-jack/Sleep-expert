package com.example.sleepexpert.View

import android.content.Context
import android.content.Intent
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.SleepDiaryViewModel
import com.example.sleepexpert.model.Diary
import java.util.Objects

class DiaryAdapter(private val context: Context, private val diaries: List<Diary>) :
    RecyclerView.Adapter<DiaryAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val sleepScore: TextView = itemView.findViewById(R.id.sleep_score)
        val startTime: TextView = itemView.findViewById(R.id.start_time)
        val endTime: TextView = itemView.findViewById(R.id.end_time)
        val viewDetailButton: Button = itemView.findViewById(R.id.detail_button)
        val deleteButton: Button = itemView.findViewById(R.id.delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diary_list, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return diaries.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val diary = diaries[position]
        holder.sleepScore.text = "Sleep Score: ${diary.score}"
        holder.startTime.text = "Start Time: ${diary.startTime}"
        holder.endTime.text = "End Time: ${diary.endTime}"

        holder.viewDetailButton.setOnClickListener {
            val intent = Intent(context, DiaryDetailActivity::class.java)
            intent.putExtra("diaryID", diary.diaryId)
            context.startActivity(intent)
        }
    }
}