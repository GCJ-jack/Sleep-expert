package com.example.sleepexpert.View

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.example.sleepexpert.R
import java.lang.Math.random
import java.util.*
import kotlin.random.Random.Default.nextInt


class ReminderService : Service() {
    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Get the reminder time from the intent
        val reminderTime = intent?.getLongExtra("REMINDER_TIME", 0) ?: 0

        // Set up the alarm manager to trigger the alarm at the reminder time
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val alarmIntent = Intent(this, SleepReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            1,
            alarmIntent,
            PendingIntent.FLAG_IMMUTABLE // or PendingIntent.FLAG_MUTABLE
        )
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent)

        // Create and display the notification


        //here we set all the properties for the notification
        val contentView = RemoteViews(packageName, R.layout.notification_layout)
        contentView.setTextViewText(R.id.title,"Sleep Reminder")
        contentView.setImageViewResource(R.id.image,R.drawable.night)
        contentView.setTextViewText(R.id.sleep_text,"Sleep reminder")
        contentView.setTextViewText(R.id.time,"22:30")
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create a notification channel for Android O and above
            val channel = NotificationChannel(
                "reminder_channel",
                "Reminder Channel",
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.enableVibration(true)
            notificationManager.createNotificationChannel(channel)
        }


        val notification = NotificationCompat.Builder(this, "reminder_channel",)
            .setSmallIcon(R.drawable.night)
            .setContentTitle("Reminder")
            .setContentText("Time to sleep!")
            .setCustomContentView(contentView)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)


        notificationManager.notify(1, notification.build())
        stopSelf()
        // Return START_STICKY to keep the service running even if the app is closed or swiped out
        return START_STICKY
    }
}