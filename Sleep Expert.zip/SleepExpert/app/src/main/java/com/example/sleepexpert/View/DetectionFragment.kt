package com.example.sleepexpert.View
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.android.volley.RequestQueue
import com.example.sleepexpert.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class DetectionFragment: Fragment(R.layout.activity_detection) {


    private lateinit var search: ImageButton
    private val ACCESS_FINE_LOCATION = 123
    private lateinit var cityTextView: TextView
    private lateinit var temperatureTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var weatherIcon: ImageView
    private lateinit var trackBtn: ImageButton
    private lateinit var viewBtn: ImageButton
    private lateinit var weatherLink: TextView
    private lateinit var humidityText: TextView
    private lateinit var pressureText: TextView
    var data: JSONObject? = null


    private val PERMISSION_LOCATION_GPS = 1001

    val url = "https://api.openweathermap.org/data/3.0/onecall?lat=33.44&lon=-94.04&exclude=hourly,daily&appid=3b911c765a42938c8e50c52b6e479c11"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the fragment's layout
        val view = inflater.inflate(R.layout.activity_detection, container, false)

        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
        val startTime:String = LocalDateTime.now().format(formatter)
        val sharedPref = context?.getSharedPreferences("my_pref", Context.MODE_PRIVATE)
        val editor = sharedPref?.edit()
        editor?.putString("start_time_key", startTime)
        editor?.apply()

        temperatureTextView = view.findViewById<TextView>(R.id.temperature)
        cityTextView = view.findViewById<TextView>(R.id.city_name)
        statusTextView = view.findViewById<TextView>(R.id.status)
        humidityText = view.findViewById(R.id.humidity)
        pressureText = view.findViewById(R.id.pressure)
        weatherIcon = view.findViewById<ImageView>(R.id.weather_icon)
        search = view.findViewById(R.id.search_button)
        weatherLink = view.findViewById(R.id.textView2)
        weatherLink.setOnClickListener(){
            val uri = Uri.parse("https://www.landofsleep.com/blog/can-a-change-in-weather-affect-your-sleep")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        search.setOnClickListener(){
            val intent = Intent(activity,TipListActivity::class.java)
            startActivity(intent)
        }

        trackBtn = view.findViewById(R.id.track)
        trackBtn.setOnClickListener(){
            val intent = Intent(activity,SensorActivity::class.java)
            startActivity(intent)
            onPause()
        }

        viewBtn = view.findViewById(R.id.check_history)
        viewBtn.setOnClickListener(){
            val intent = Intent(activity,SleepHistory::class.java)
            startActivity(intent)
            onPause()
        }



        checkpermission()
        return view
    }


    /**
     * Checks for permissions
     */
    @SuppressLint("MissingPermission")
    private fun checkpermission(){
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    requireActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            ) {
            } else {
                ActivityCompat.requestPermissions(
                    requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    ACCESS_FINE_LOCATION
                )
            }
            return
        }
    }

    private fun refreshLatLon() {
        val locationMgr = requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PERMISSION_LOCATION_GPS)
        } else {
            val locationListener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    val lat = location.latitude
                    val lon = location.longitude
                    getJSON(lat,lon)
                    locationMgr.removeUpdates(this)
                }
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }
            locationMgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0f, locationListener)
        }
    }


    override fun onStart() {
        super.onStart()
        refreshLatLon()
    }


    fun getJSON(lat: Double, lon: Double) {

        val apiKey = "3b911c765a42938c8e50c52b6e479c11"
        val url = "http://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey"

        object : AsyncTask<Void, Void, JSONObject>() {

            override fun doInBackground(vararg params: Void?): JSONObject? {
                try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connect()

                    val responseCode = connection.responseCode
                    if (responseCode != HttpURLConnection.HTTP_OK) {
                        return null
                    }

                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    val json = StringBuilder(1024)
                    var tmp: String?

                    while (reader.readLine().also { tmp = it } != null) {
                        json.append(tmp).append("\n")
                    }
                    reader.close()

                    return JSONObject(json.toString())

                } catch (e: Exception) {
                    e.printStackTrace()
                    return null
                }
            }

            override fun onPostExecute(result: JSONObject?) {
                super.onPostExecute(result)
                if (result != null) {
                    val main = result.getJSONObject("main")
                    val temp = main.getDouble("temp")
                    val city = result.getString("name")
                    val weather = result.getJSONArray("weather").getJSONObject(0)
                    val mainWeather = weather.getString("main")
                    val icon = weather.getString("icon")
                    val pressure = main.getInt("pressure")
                    val humidity = main.getInt("humidity")
                    Log.d("pressure", pressure.toString())
                    val iconUrl = "https://openweathermap.org/img/wn/${icon}@2x.png"
                    Picasso.get().load(iconUrl).into(weatherIcon)
                    temperatureTextView.text = String.format("%.1f °F", temp)
                    cityTextView.text = city
                    statusTextView.text = mainWeather
                    pressureText.text = "Pressure: "+ pressure.toString()+" hPa"
                    humidityText.text = "Humidity: "+ humidity.toString()+"%"
                }
            }
        }.execute()
    }

    override fun onPause() {
        super.onPause()
    }
}