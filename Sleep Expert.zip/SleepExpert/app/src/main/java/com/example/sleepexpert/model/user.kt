package com.example.sleepexpert.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class user(@PrimaryKey(autoGenerate = true) var id: Int = 0,
                var name: String="",
                var email: String,
                var password: String,
                var sleepReminder: String? = null,
                var wakeupAlarm: String? = null,
                var sleepTarget: Double? =null) {}

