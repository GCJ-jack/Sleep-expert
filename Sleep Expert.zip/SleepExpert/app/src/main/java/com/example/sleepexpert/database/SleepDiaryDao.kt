package com.example.sleepexpert.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SleepDiaryDao {

    @Query("Select * from sleepDiary ORDER by user_id ASC")
    suspend fun getItems(): List<SleepDiary>

    // Useful for tracking Entities
//    @Query("Select * from sleepDiary Where diaryId = :id")
//    suspend fun getItem(id: Int): SleepDiary

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(diary: SleepDiary): Long

    @Update
    suspend fun update(diary: SleepDiary)

    @Delete
    suspend fun delete(diary: SleepDiary)

    @Query("SELECT * FROM sleepDiary WHERE user_id = :userId ORDER BY start_time ASC")
    suspend fun getSleepDiaries(userId: Int): List<SleepDiary>

    @Query("SELECT * FROM sleepDiary WHERE diaryId= :diaryId")
    suspend fun getSleepDiaryById(diaryId: Int): SleepDiary

    @Query("SELECT duration FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastSevenDuration(userId: Int): List<String>

    @Query("SELECT start_time FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastSevenDate(userId: Int): List<String>

    @Query("SELECT end_time FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastWakeUpTime(userId: Int): List<String>

    @Query("SELECT light FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastSevenLightLevel(userId: Int): List<Long>

    @Query("SELECT temperature FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastSevenTemperatureLevel(userId: Int): List<Long>

    @Query("SELECT humidity FROM sleepDiary WHERE user_id = :userId ORDER BY diaryId DESC LIMIT 7")
    suspend fun getLastSevenHumidityLevel(userId: Int): List<Float>

    @Query("SELECT COUNT(*) FROM sleepDiary WHERE user_id = :userId")
    suspend fun getSleepDiaryCount(userId: Int): Int

    @Query("SELECT duration FROM sleepDiary WHERE user_id = :userId")
    suspend fun getAllTheDuration(userId: Int): List<String>
}