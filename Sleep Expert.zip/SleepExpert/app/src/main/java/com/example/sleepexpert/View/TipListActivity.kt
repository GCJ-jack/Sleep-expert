package com.example.sleepexpert.View

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.sleepexpert.R
import com.example.sleepexpert.model.Diary


class TipListActivity: AppCompatActivity() {
    private lateinit var simpleList: ListView


    var tipList = arrayOf("Diagnosis of insomnia","How room condition affect sleep quality","How to improve sleep quality", "How food affect your sleep", "How meditation affect your sleep", "How weather affect your sleep", "How emotion affect your sleep", "How exercise affect your sleep")
    private var picture = intArrayOf(
        R.drawable.insomnia,
        R.drawable.bedroom,
        R.drawable.nhs,
        R.drawable.foodimage,
        R.drawable.meditation,
        R.drawable.weather,
        R.drawable.emotion,
        R.drawable.exercise
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tips)

        simpleList = findViewById(R.id.simpleListView)

        val tipsAdapter = TipsAdapter(applicationContext, tipList, picture)

        simpleList.adapter = tipsAdapter

        simpleList.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            // Define the URLs you want to open for each item
            val urls = arrayOf(
                "https://www.sleepfoundation.org/insomnia",
                "https://www.sleepfoundation.org/bedroom-environment",
                "https://www.sleepfoundation.org/bedroom-environment",
                "https://www.nhs.uk/every-mind-matters/coronavirus/how-to-fall-asleep-faster-and-sleep-better/",
                "https://www.sleepfoundation.org/nutrition/food-and-sleep",
                "https://www.sleepfoundation.org/meditation-for-sleep",
                "https://www.dreams.co.uk/sleep-matters-club/barometric-pressure-affect-sleep",
                "https://www.betterhealth.vic.gov.au/health/healthyliving/Mood-and-sleep",
                "https://www.sleepfoundation.org/physical-activity/exercise-and-sleep"

            )

            // Launch a browser intent to open the URL for the clicked item
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(urls[position])
            startActivity(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        finish()
    }
}