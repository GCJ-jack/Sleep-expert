package com.example.sleepexpert.View

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.util.Log
import androidx.lifecycle.MutableLiveData
import java.lang.Exception

class Lightness(context: Context) {
    private val LIGHT_READING_FREQ_MICRO_SEC: Int = 30000
    private var samplingRateInMicroSec: Long = LIGHT_READING_FREQ_MICRO_SEC.toLong()
    private var samplingRateInNanoSec: Long = samplingRateInMicroSec * 1000
    private var timePhoneWasLastRebooted: Long = 0
    private var lastReportTime: Long = 0

    private var sensorManager: SensorManager?
    private var lightnessSensor: Sensor
    private var lightnessEventListener: SensorEventListener? = null
    private var _isStarted = false

    val isStarted: Boolean
        get() {return _isStarted}

    var lightnessReading: MutableLiveData<Float> = MutableLiveData<Float>()


    init{
        // http://androidforums.com/threads/how-to-get-time-of-last-system-boot.548661/
        timePhoneWasLastRebooted = System.currentTimeMillis() - SystemClock.elapsedRealtime()

        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightnessSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)!!

        /**
         * this inits the listener and establishes the actions to take when a sensor is available
         * It is not registere to listen at this point, but makes sure the object is available to
         * listen when registered.
         */
        lightnessEventListener  = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {



//                val actualTimeInMseconds = this@Lightness.timePhoneWasLastRebooted + (event.timestamp / 1000000.0).toLong()
                // In this example, only updating the LiveData (hence UI gets update),
                // when there is a new pressue value - no need for a UI update otherwise
                if(lightnessReading.value != event.values[0]){lightnessReading.value = event.values[0]}
                val accuracy = event.accuracy
//                Log.i(
//                    TAG,
//                    Utilities.mSecsToString(actualTimeInMseconds) +
//                            ": current lightness: " +
//                            lightnessReading.value + "with accuracy: " + accuracy
////                                setLastReportTime(actualTimeInMseconds)
//                )
                this@Lightness.lastReportTime = event.timestamp
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
    }

    companion object {
        private val TAG = Lightness::class.java.simpleName

    }

    /**
     * it starts the pressure monitoring and updates the _isStarted status flag
     * @param accelerometer
     */
    fun startLightnessSensing() {
        sensorManager?.let {

            it.registerListener(
                lightnessEventListener,
                lightnessSensor,
                SensorManager.SENSOR_DELAY_UI
            )
            _isStarted = true
        }
    }

    /**
     * this stops the barometer and updates the _isStarted status flag
     */
    fun stopLightnessSensing() {
        sensorManager?.let {
            try {
                it.unregisterListener(lightnessEventListener)
                _isStarted = false
            } catch (e: Exception) {
                // probably already unregistered
            }
        }
    }
}