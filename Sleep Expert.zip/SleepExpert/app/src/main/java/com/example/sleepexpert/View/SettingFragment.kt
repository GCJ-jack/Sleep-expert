package com.example.sleepexpert.View

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.ViewModel.SleepDiaryViewModel
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.launch

class SettingFragment: Fragment(R.layout.setting_fragment) {

    private lateinit var totalSleep: TextView
    private lateinit var averageSleep: TextView
    private lateinit var sleepTarget: TextView
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var changePassword: Button


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.setting_fragment, container, false)

        val sharedPref = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("userId", -1)
        val userDao = AppDatabase.getInstance(requireContext()).userDataDao()
        val userRepository = UserRepository(userDao)
        totalSleep = view.findViewById(R.id.total_sleep)
        val sleepDiaryViewModel = ViewModelProvider(this)[SleepDiaryViewModel::class.java]
        loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)
        sleepTarget = view.findViewById(R.id.sleeptarget)
        averageSleep = view.findViewById(R.id.sleephours)
        changePassword = view.findViewById(R.id.passwordButton)
        lifecycleScope.launch {
            val nights = sleepDiaryViewModel.getSleepDiarySize(userId)
            totalSleep.text = "Nights: " + nights
            val target = loginViewModel.getSleepTarget(userId)
            sleepTarget.text = "Your sleep target: " + target + " hours"
            var averageDuration = 0.0
            val allDuration = sleepDiaryViewModel.getAllDuration(userId)
            for (duration in allDuration) {
                val newDuration = duration.split(":")
                val hour = newDuration[0]
                val minute = newDuration[1]
                val second = newDuration[2]
                averageDuration += (hour.toDouble() + minute.toDouble() / 60 + second.toDouble() / 3600) / allDuration.size
            }
            averageSleep.text = averageDuration.toString() + " hours"
        }
        changePassword.setOnClickListener(){
            val dialog = ChangePasswordDialogFragment()
            dialog.show(parentFragmentManager, "ChangePasswordDialog")
        }
        return view
    }


}

