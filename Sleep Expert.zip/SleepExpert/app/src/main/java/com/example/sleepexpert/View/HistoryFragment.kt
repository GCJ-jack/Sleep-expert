package com.example.sleepexpert.View

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.sleepexpert.R
import com.example.sleepexpert.ViewModel.LoginViewModel
import com.example.sleepexpert.ViewModel.LoginViewModelFactory
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.launch
import java.util.*

class HistoryFragment: Fragment(R.layout.activity_history) {

    private lateinit var sleepReminder: EditText
    private lateinit var sleepAlarm: EditText
    private lateinit var medicationReminder: EditText
    private lateinit var sleepTarget: EditText
    private lateinit var updateBtn: Button
    lateinit var timePickerDialog: TimePickerDialog
    var calendar: Calendar = Calendar.getInstance()
    var currentHour = 0
    var currentMinute = 0
    var amPm: String? = null
    private lateinit var loginViewModel: LoginViewModel


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the fragment's layout

        val view = inflater.inflate(R.layout.activity_history, container, false)

        val sharedPref = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("userId", -1)

        val userDao = AppDatabase.getInstance(requireContext()).userDataDao()
        val userRepository = UserRepository(userDao)
        loginViewModel = ViewModelProvider(this, LoginViewModelFactory(userRepository)).get(LoginViewModel::class.java)

        sleepReminder = view.findViewById(R.id.sleep_reminder_time_field)
        sleepAlarm = view.findViewById(R.id.sleep_alarm_field)
        sleepAlarm.setOnClickListener(){
            timeOnClick(requireContext(),sleepAlarm)
        }
        sleepTarget = view.findViewById(R.id.target_field)
        sleepTarget.inputType = InputType.TYPE_CLASS_NUMBER
        lifecycleScope.launch{
            val reminderTime = loginViewModel.getSleepReminder(userId)
            val alarmTime = loginViewModel.getAlarmTime(userId)
            val target = loginViewModel.getSleepTarget(userId)
            sleepReminder.setText(reminderTime)
            sleepTarget.setText(target.toString())
            sleepAlarm.setText(alarmTime.toString())
            val editor = sharedPref.edit()
            if (target != null) {
                editor.putInt("target",target.toInt())
            }
            if (alarmTime != null){
                editor.putString("alarm-time",alarmTime)
            }
            if (reminderTime !=null){
                editor.putString("reminder",reminderTime)
            }
            editor.apply()
        }
        sleepReminder.setOnClickListener(){
            timeOnClick(requireContext(),sleepReminder)
        }
        medicationReminder = view.findViewById(R.id.medication_reminder_field)
        medicationReminder.setOnClickListener(){
            timeOnClick(requireContext(),medicationReminder)
        }

        updateBtn = view.findViewById(R.id.updateBtn)
        updateBtn.setOnClickListener(){
            val reminderTime = sleepReminder.text.toString()
            val alarmTime = sleepAlarm.text.toString()
            val sleepTarget = sleepTarget.text.toString().toDoubleOrNull()
            lifecycleScope.launch {
                loginViewModel.updateAllReminder(reminderTime, sleepTarget,alarmTime,userId)
            }
            Toast.makeText(requireContext(), "Reminder time updated", Toast.LENGTH_SHORT).show()
        }
        return view
    }

    fun timeOnClick(context: Context,chooseTime: EditText) {
        calendar = Calendar.getInstance()
        currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        currentMinute = calendar.get(Calendar.MINUTE)
        timePickerDialog = TimePickerDialog(context,
            { timePicker, hourOfDay, minutes ->
                if (hourOfDay >= 12) {
                    amPm = "PM"
                } else {
                    amPm = "AM"
                }
                chooseTime.setText(String.format("%02d:%02d", hourOfDay, minutes) + amPm)
            }, currentHour, currentMinute, false
        )
        timePickerDialog.show()
    }
}