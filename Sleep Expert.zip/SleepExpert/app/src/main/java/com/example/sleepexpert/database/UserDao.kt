package com.example.sleepexpert.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.sleepexpert.model.user
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    @Query("Select * from user ORDER by id ASC")
    fun getUsers(): Flow<List<User>>

    // Useful for tracking Entities
    @Query("Select * from user Where id = :id")
    fun getUser(id: Int): Flow<User>

    @Query("Select * from user Where e_mail= :email AND password = :password")
    fun getUserByEmailAndPassword(email: String, password: String): User

    @Query("Select id from user Where e_mail= :email")
    fun getUserIdByEmail(email: String): Int

    @Query("Select full_Name from user Where id= :id")
    fun getUserNameById(id: Int): String

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(userData: User)

    @Update
    suspend fun update(userData: User)

    @Delete
    suspend fun delete(userData: User)

    @Query("UPDATE user SET sleep_reminder = :sleepReminder, sleep_target = :sleepTarget, wakeup_alarm =:wakeUpAlarm WHERE id = :id")
    suspend fun updateAllTheReminder(sleepReminder: String?, sleepTarget :Double?, wakeUpAlarm :String?,id: Int)

    @Query("Select wakeup_alarm from user Where id=:id")
    suspend fun readAlarmTime(id: Int): String?

    @Query("Select sleep_reminder from user Where id=:id")
    suspend fun readSleepReminder(id: Int): String?

    @Query("Select sleep_target from user Where id=:id")
    suspend fun readSleepTarget(id: Int): Double?

}