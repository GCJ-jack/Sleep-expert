package com.example.sleepexpert.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")
data class User(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    @ColumnInfo(name = "full_name") var fullName: String,
    @ColumnInfo(name = "e_mail") var email: String,
    @ColumnInfo(name = "password") var password: String,
    @ColumnInfo(name="sleep_reminder") var sleepReminder: String?="22:00PM",
    @ColumnInfo(name = "sleep_target") var sleepTarget: Double?=8.0,
    @ColumnInfo(name="wakeup_alarm") var wakeUpAlarm: String?="08:00AM"
    )
{}
