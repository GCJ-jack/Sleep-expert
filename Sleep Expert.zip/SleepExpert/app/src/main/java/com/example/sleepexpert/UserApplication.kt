package com.example.sleepexpert

import android.app.Application
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.repository.UserRepository


class UserApplication:Application() {
    // This has been updated to initialize the repository along with the database when the
    // using by lazy again,which ensures either are created until they are
    // needed (i.e. referenced for the first time).
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: UserRepository by lazy{UserRepository(database.userDataDao())}
}