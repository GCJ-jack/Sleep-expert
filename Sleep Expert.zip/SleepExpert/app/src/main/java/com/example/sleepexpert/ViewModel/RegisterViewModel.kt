package com.example.sleepexpert.ViewModel


import android.app.Application
import androidx.lifecycle.*

import androidx.room.Room
import com.example.sleepexpert.database.AppDatabase
import com.example.sleepexpert.database.User
import com.example.sleepexpert.database.UserDao
import com.example.sleepexpert.model.user
import com.example.sleepexpert.repository.UserRepository
import kotlinx.coroutines.launch

class RegisterViewModel(private val applicationContext: Application): AndroidViewModel(applicationContext) {
    // LiveData to hold the user information
    private val userRepository: UserRepository
    val user = MutableLiveData<user>()

    // Method to register the user
    init {
        val database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "Sleep"
        ).build()
        userRepository = UserRepository(database.userDataDao())
    }

    fun registerUser(user: user) = viewModelScope.launch {
        userRepository.registerUser(user)
    }



    // Extends the ViewModelProvider.Factory allowing us to control the viewmodel creation
// and provide the right parameters

}
class RegisterViewModelFactory(private val repository: UserRepository,  private val applicationContext: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RegisterViewModel::class.java)) {
            return RegisterViewModel(applicationContext) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}